<template>
    <div>
        <h2>Recipe Page</h2>
    </div>
</template>
<script>
export default {
    name: 'RecipePage',
}
</script>