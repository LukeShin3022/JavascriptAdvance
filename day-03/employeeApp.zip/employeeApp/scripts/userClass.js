class userClass{
    #firstName;
    #lastName;
    #email;
    #telephone;
    #address;
    #dob;
    #ed;
    #departmentId;
    #positionId;
    #depName;
    #poName;
    constructor(firstName,lastName,email,telephone,address,dob,ed,did,pid){
        this.#firstName = firstName;
        this.#lastName = lastName;
        this.#email = email;
        this.#telephone = telephone;
        this.#address = address;
        this.#dob = dob;
        this.#ed = ed;
        this.#departmentId = did;
        this.#positionId = pid;
    }
    #searchId(obj,id,proName){
        if(obj[proName] == id){
            return obj;
        }
        return false;
    }
    fillPosition(){
        fetch('./data/positions.json').then(
            (response)=>{
                response.json().then(
                    (jsonData)=>{
                        jsonData.forEach((obj)=>{
                            let pObj = this.#searchId(obj,this.#positionId,'pid');
                            if(pObj) {
                                this.#poName = pObj['p_name'];
                                return false;
                            }
                        })
                    }
                )
            }
        )
    }

}
export default userClass;